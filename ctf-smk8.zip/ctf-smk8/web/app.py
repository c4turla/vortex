from flask import Flask, request, render_template_string, send_file, os
import sqlite3

app = Flask(__name__)
DB_NAME = "ctf.db"

# Inisialisasi Database
def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    
    # Tabel Produk (Normal)
    c.execute('''CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY, 
        name TEXT, 
        price TEXT, 
        description TEXT
    )''')
    
    # Tabel Rahasia (Hidden)
    c.execute('''CREATE TABLE IF NOT EXISTS secret_flags (
        id INTEGER PRIMARY KEY,
        flag TEXT
    )''')
    
    # Isi Data Produk
    c.execute("INSERT OR IGNORE INTO products (id, name, price, description) VALUES (1, 'Laptop SMK', '5000000', 'Laptop untuk praktik')")
    c.execute("INSERT OR IGNORE INTO products (id, name, price, description) VALUES (2, 'Mouse Wireless', '150000', 'Mouse tanpa kabel')")
    
    # Isi Flag Rahasia
    c.execute("INSERT OR IGNORE INTO secret_flags (id, flag) VALUES (1, 'CTFSMKN8{Un10n_s3lect_m4st3r_5mk}')")
    
    conn.commit()
    conn.close()

init_db()

# --- CHALLENGE 1: SQL Injection (Union Based) ---
@app.route('/produk', methods=['GET'])
def produk():
    product_id = request.args.get('id', '1')
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    
    # Vulnerable Query
    query = f"SELECT id, name, price, description FROM products WHERE id = {product_id}"
    
    try:
        c.execute(query)
        results = c.fetchall()
    except sqlite3.Error as e:
        results = f"Error Database: {str(e)}"
    
    conn.close()
    
    # Hint untuk siswa (disembunyikan di HTML Comment)
    html = """
    <!-- Hint: Tabel rahasia bernama 'secret_flags'. Query utama memiliki 4 kolom. -->
    <h1>Challenge 1: Toko Online</h1>
    <p>Lihat detail produk berdasarkan ID. Temukan flag yang tersimpan di database rahasia.</p>
    <p>ID Produk saat ini: <b>{{ pid }}</b></p>
    <hr>
    <table border="1" cellpadding="10">
        <tr><th>ID</th><th>Nama</th><th>Harga</th><th>Deskripsi</th></tr>
        {% for row in results %}
        <tr>
            <td>{{ row[0] }}</td>
            <td>{{ row[1] }}</td>
            <td>{{ row[2] }}</td>
            <td>{{ row[3] }}</td>
        </tr>
        {% endfor %}
    </table>
    <br>
    <a href="/komentar">Lanjut ke Challenge 2</a>
    """
    return render_template_string(html, pid=product_id, results=results)

# --- CHALLENGE 2: XSS (Cross Site Scripting) ---
@app.route('/komentar', methods=['GET', 'POST'])
def komentar():
    name = ""
    comment = ""
    if request.method == 'POST':
        name = request.form['name']
        comment = request.form['comment']
    
    # Vulnerable: Tidak ada sanitasi
    html = f"""
    <h1>Challenge 2: Buku Tamu</h1>
    <p>Jika Anda bisa membuat popup alert, Anda mendapatkan flag.</p>
    <form method="POST">
        <input type="text" name="name" placeholder="Nama"><br><br>
        <textarea name="comment" placeholder="Komentar"></textarea><br><br>
        <button type="submit">Kirim</button>
    </form>
    <hr>
    <h3>Komentar Terbaru:</h3>
    <p><b>{name}</b>: {comment}</p>
    """
    # Logika flag sederhana untuk level SMK
    if "<script>" in comment.lower():
        return "Flag 2: CTFSMKN8{x5s_r3flect3d_d4nger0us}"
    return render_template_string(html)

# --- CHALLENGE 3: Path Traversal ---
@app.route('/baca')
def baca():
    file = request.args.get('file', 'welcome.txt')
    try:
        # Flag disimpan di /tmp agar bisa diakses via traversal
        path = os.path.join('/app/files', file)
        return send_file(path)
    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == '__main__':
    # Setup file untuk Path Traversal
    os.makedirs('/app/files', exist_ok=True)
    with open('/app/files/welcome.txt', 'w') as f:
        f.write("Selamat datang di challenge baca file.")
    with open('/tmp/flag.txt', 'w') as f:
        f.write("Flag 3: CTFSMKN8{p4th_tr4v3rsal_etc_p4sswd}")
    
    app.run(host='0.0.0.0', port=5000, debug=True)