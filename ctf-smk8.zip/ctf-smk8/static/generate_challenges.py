import os
import base64
import zipfile
from struct import pack

# Direktori output
os.makedirs('/usr/share/nginx/html/crypto', exist_ok=True)
os.makedirs('/usr/share/nginx/html/forensics', exist_ok=True)

print("[*] Generating Cryptography Challenges...")

# --- CRYPTO 1: Vigenere Cipher ---
# Flag: CTFSMKN8{v1g3n3re_cl4ss1c_c1ph3r}
# Key: SMK
def vigenere_encrypt(plaintext, key):
    ciphertext = []
    key = key.upper()
    key_index = 0
    for char in plaintext:
        if char.isalpha():
            shift = ord(key[key_index % len(key)]) - ord('A')
            if char.islower():
                ciphertext.append(chr((ord(char) - ord('a') + shift) % 26 + ord('a')))
            else:
                ciphertext.append(chr((ord(char) - ord('A') + shift) % 26 + ord('A')))
            key_index += 1
        else:
            ciphertext.append(char)
    return ''.join(ciphertext)

flag1 = "CTFSMKN8{v1g3n3re_cl4ss1c_c1ph3r}"
enc1 = vigenere_encrypt(flag1, "SMK")
with open('/usr/share/nginx/html/crypto/vigenere.txt', 'w') as f:
    f.write(f"Ciphertext: {enc1}\nHint: Key adalah nama sekolah (3 huruf).\n")

# --- CRYPTO 2: XOR Encryption ---
# Flag: CTFSMKN8{x0r_l0g1c_pr0gr4mm1ng}
# Key: 0x5A
flag2 = "CTFSMKN8{x0r_l0g1c_pr0gr4mm1ng}"
key2 = 0x5A
encrypted_bytes = [b ^ key2 for b in flag2.encode()]
hex_output = ''.join([f"{b:02x}" for b in encrypted_bytes])

encrypt_script = """
flag = "????"
key = 0x5A
encrypted = [ord(c) ^ key for c in flag]
print(encrypted)
"""
with open('/usr/share/nginx/html/crypto/xor_challenge.py', 'w') as f:
    f.write(encrypt_script)

with open('/usr/share/nginx/html/crypto/xor_output.txt', 'w') as f:
    f.write(f"Hex Result: {hex_output}\n")

# --- CRYPTO 3: Encoding Chain ---
# Flag: CTFSMKN8{3nc0d1ng_ch41n_m4st3r}
# Process: Flag -> Reverse -> Base64
flag3 = "CTFSMKN8{3nc0d1ng_ch41n_m4st3r}"
step1 = flag3[::-1] # Reverse
step2 = base64.b64encode(step1.encode()).decode() # Base64
with open('/usr/share/nginx/html/crypto/encoding.txt', 'w') as f:
    f.write(f"Decode ini: {step2}\n")

print("[*] Generating Forensics Challenges...")

# --- FORENSICS 1: File Carving (ZIP inside JPG) ---
# Flag: CTFSMKN8{f1l3_c4rv1ng_b1nw4lk}
flag4 = "CTFSMKN8{f1l3_c4rv1ng_b1nw4lk}"
jpg_header = b'\xFF\xD8\xFF\xE0\x00\x10JFIF' + b'\x00' * 100 
zip_data = zipfile.ZipFile('/tmp/secret.zip', 'w')
zip_data.writestr('flag.txt', flag4)
zip_data.close()
with open('/tmp/secret.zip', 'rb') as f:
    zip_content = f.read()

with open('/usr/share/nginx/html/forensics/image.jpg', 'wb') as f:
    f.write(jpg_header)
    f.write(zip_content)

# --- FORENSICS 2: Network Forensics (PCAP) ---
# Flag: CTFSMKN8{w1r3sh4rk_http_p0rt}
try:
    from scapy.all import *
    flag5 = "CTFSMKN8{w1r3sh4rk_http_p0rt}"
    
    packet = Ether()/IP(src="192.168.1.10", dst="192.168.1.1")/TCP(sport=12345, dport=80, flags="PA")/Raw(load=f"POST /login HTTP/1.1\r\nHost: ctf.local\r\nContent-Length: 30\r\n\r\nusername=admin&password={flag5}")
    
    wrpcap('/usr/share/nginx/html/forensics/traffic.pcap', packet)
except Exception as e:
    with open('/usr/share/nginx/html/forensics/traffic.pcap', 'w') as f:
        f.write("Error generating PCAP.")
    print(f"[!] Scapy error: {e}")

# --- FORENSICS 3: Metadata (EXIF) ---
# Flag: CTFSMKN8{m3t4dat4_3x1f_h1dd3n}
try:
    from PIL import Image
    from PIL.PngImagePlugin import PngInfo
    
    flag6 = "CTFSMKN8{m3t4dat4_3x1f_h1dd3n}"
    
    img = Image.new('RGB', (100, 100), color='red')
    meta = PngInfo()
    meta.add_text("Comment", flag6)
    
    img.save('/usr/share/nginx/html/forensics/photo.png', pnginfo=meta)
except Exception as e:
    with open('/usr/share/nginx/html/forensics/photo.png', 'w') as f:
        f.write("Error generating Image.")
    print(f"[!] Pillow error: {e}")

print("[+] All challenges generated successfully!")